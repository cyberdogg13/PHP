<?php
echo "dit is beter toch";
?>

<a href="../index.php">terug naar het hoofdmenu</a>
